import React from "react";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import { faArrowLeft } from "@fortawesome/free-solid-svg-icons";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const TodoItem=({todo, onDelete})=> {
  return (
    <div>
      <h4>{todo.title}</h4>  
      <button className="btn btn-sm btn-danger" onClick = {()=> {onDelete(todo)}}>Delete</button><hr/>
      <div className="pull-right">
      <button>
                  <FontAwesomeIcon icon={faArrowLeft} />
                </button> 
                <button>
                <FontAwesomeIcon icon={faArrowRight} />
              </button>
    </div>
    </div>
  );
}

export default TodoItem;

// <div>
//     <div class="pull-left">
//         <button type="button" class="btn">Delete</button>
//     </div>
//     <div>
//         <div class="input-group">
//             <input type="text" class="form-control" value="1" />
//             <span class="input-group-addon">Update</span>
//         </div>
//     </div>
// </div>